﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Frizerski_salon
{
    public partial class Raspored : Form
    {
        public Raspored()
        {
            InitializeComponent();
        }

        private void Raspored_Load(object sender, EventArgs e)
        {
            Grid_fill();
        }
        private void Grid_fill()
        {
            SqlConnection veza = Klasa.conn;
            SqlCommand comm = new SqlCommand("dbo.Musterija_za_danas", veza);
            comm.CommandType = CommandType.StoredProcedure;
            comm.Parameters.Add(new SqlParameter("@sifra", SqlDbType.NVarChar, 50, ParameterDirection.Input, false, 0, 0, "", DataRowVersion.Current, Klasa.sifra_frizera ));
            comm.Parameters.Add(new SqlParameter("@ime", SqlDbType.NVarChar, 50, ParameterDirection.Input, false, 0, 0, "", DataRowVersion.Current, Klasa.ime_frizera));
            comm.Parameters.Add(new SqlParameter("@prezime", SqlDbType.NVarChar, 50, ParameterDirection.Input, false, 0, 0, "", DataRowVersion.Current,Klasa.prezime_frizera ));
            comm.Parameters.Add(new SqlParameter("@datum", SqlDbType.Date, 50, ParameterDirection.Input, false, 0, 0, "", DataRowVersion.Current, dateTimePicker1.Value));
            SqlDataAdapter adapter = new SqlDataAdapter(comm);
            

            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            dataGridView1.Sort(dataGridView1.Columns[1], ListSortDirection.Ascending);
            
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            Grid_fill();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Zakazi frm_z = new Zakazi();
            frm_z.Show();
        }
    }
}
