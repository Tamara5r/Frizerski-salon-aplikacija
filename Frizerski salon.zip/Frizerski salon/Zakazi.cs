﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Frizerski_salon
{
    public partial class Zakazi : Form
    {
        public Zakazi()
        {
            InitializeComponent();
        }
        private void CB_frizer()
        {
            SqlConnection veza = Klasa.conn;
            SqlDataAdapter adapter = new SqlDataAdapter("select id, ime+' '+prezime as naziv from frizer",veza);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            comboBox1.DataSource = dt;
            comboBox1.DisplayMember = "naziv";
            comboBox1.ValueMember = "id";
        }
        private void CB_vreme()
        {
            SqlConnection veza = Klasa.conn;
            SqlCommand comm = new SqlCommand("dbo.nadji_termin2", veza);
            comm.CommandType = CommandType.StoredProcedure;
            comm.Parameters.Add(new SqlParameter("@datum", SqlDbType.Date, 100, ParameterDirection.Input, false, 0, 0, "", DataRowVersion.Current, dateTimePicker1.Value));
            SqlDataAdapter adapter = new SqlDataAdapter(comm);
            DataTable dt = new DataTable();
            adapter.Fill(dt);

            comboBox2.DataSource = dt;
            comboBox2.DisplayMember = "naziv";
            comboBox2.ValueMember = "id_termina";

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           


        }

        private void Zakazi_Load(object sender, EventArgs e)
        {
            dateTimePicker1.Value = DateTime.Now;
            CB_frizer();
            CB_vreme();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            CB_vreme();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text!="" && textBox2.Text!="" && textBox3.Text!="")
            {
                SqlConnection veza = Klasa.conn;
                SqlCommand comm = new SqlCommand("dbo.unos", veza);
                comm.CommandType = CommandType.StoredProcedure;
                int tel = Convert.ToInt32(textBox2.Text);
                comm.Parameters.Add(new SqlParameter("@ime", SqlDbType.NVarChar, 100, ParameterDirection.Input, false, 0, 0, "", DataRowVersion.Current, textBox1.Text));
                comm.Parameters.Add(new SqlParameter("@telefon", SqlDbType.Int, 100, ParameterDirection.Input, false, 0, 0, "", DataRowVersion.Current,tel));
                comm.Parameters.Add(new SqlParameter("@mail", SqlDbType.NVarChar, 100, ParameterDirection.Input, false, 0, 0, "", DataRowVersion.Current, textBox3.Text));
                comm.Parameters.Add(new SqlParameter("@imef", SqlDbType.Int, 100, ParameterDirection.Input, false, 0, 0, "", DataRowVersion.Current, comboBox1.SelectedValue));
                comm.Parameters.Add(new SqlParameter("@termin", SqlDbType.Int, 100, ParameterDirection.Input, false, 0, 0, "", DataRowVersion.Current, comboBox2.SelectedValue));
                comm.Parameters.Add(new SqlParameter("@datum", SqlDbType.DateTime, 100, ParameterDirection.Input, false, 0, 0, "", DataRowVersion.Current,dateTimePicker1.Value));
                veza.Open();
                comm.ExecuteNonQuery();
                veza.Close();
                CB_vreme();
            }
            else
            {
                MessageBox.Show("Molimo unesite sve potrebne podatke");
            }
        }

        private void rasporedZaFrizeraToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Pocetna frm_p = new Pocetna();
            frm_p.Show();
        }
    }
}
