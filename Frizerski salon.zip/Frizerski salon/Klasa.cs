﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace Frizerski_salon
{
    public class Klasa
    {
        public static string ime_frizera;
        public static string prezime_frizera;
        public static string sifra_frizera;
        public static SqlConnection conn = new SqlConnection("Data Source=HP261020;Initial Catalog=frizer_kalendar;Integrated Security=True");

        
    }
}
