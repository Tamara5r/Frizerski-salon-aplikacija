﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Frizerski_salon
{
    public partial class Pocetna : Form
    {
        public Pocetna()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string ime = textBox1.Text;
            string prezime = textBox2.Text;
            string sifra = textBox3.Text;
            if (ime == ""   ) { MessageBox.Show("Molilo unesite ime"); }
            else if (prezime=="") { MessageBox.Show("Molilo unesite prezime"); }
            else if(sifra == "") { MessageBox.Show("Molilo unesite sifru"); }
            else { 
            int pr = provera(ime, prezime, sifra);
            if (pr == 1)
            {

                    MessageBox.Show("Uspesan login");
                    Klasa.sifra_frizera = sifra;
                    Klasa.ime_frizera = textBox1.Text;
                    Klasa.prezime_frizera = textBox2.Text;
                    Raspored form_r = new Raspored();
                    form_r.Show();
                    this.Hide();
            }
            else
            {
                    MessageBox.Show("Netacni podaci, molimo ponovite unos");
                    textBox1.Text = "";
                    textBox2.Text = "";
                    textBox3.Text = "";
                }
            }
        }
        public int provera(string ime, string prezime, string sifra)
        {

            SqlConnection conn = new SqlConnection("Data Source=HP261020;Initial Catalog=frizer_kalendar;Integrated Security=True");

            int rezultat;
            SqlCommand comm = new SqlCommand("dbo.provera_frizera", conn);
            comm.CommandType = CommandType.StoredProcedure;
            comm.Parameters.Add(new SqlParameter("@ime", SqlDbType.NVarChar, 100, ParameterDirection.Input, false, 0, 0, "", DataRowVersion.Current, ime));
            comm.Parameters.Add(new SqlParameter("@prezime", SqlDbType.NVarChar, 100, ParameterDirection.Input, false, 0, 0, "", DataRowVersion.Current, prezime));
            comm.Parameters.Add(new SqlParameter("@sifra", SqlDbType.NVarChar, 100, ParameterDirection.Input, false, 0, 0, "", DataRowVersion.Current, sifra));
            comm.Parameters.Add(new SqlParameter("@RETURN_VALUE", SqlDbType.Int, 4, ParameterDirection.ReturnValue, true, 0, 0, "", DataRowVersion.Current, null));
            conn.Open();
            comm.ExecuteNonQuery();
            conn.Close();


            int Ret;
            Ret = (int)comm.Parameters["@RETURN_VALUE"].Value;
            if (Ret == 0)
            {
                rezultat = 0;
            }

            else
            {
                rezultat = 1;
            }
            return rezultat;
        }

        private void Pocetna_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Zakazi frm_z = new Zakazi();
            frm_z.Show();
            this.Hide();
        }
    }
}
