go
create database rad_osoba
go

go
use rad_osoba
go

go 
create table predmet(
id int primary key identity(1,1),
naziv nvarchar(30),
razred nvarchar(20)
)
go

go 
create table smer(
id int primary key identity(1,1),
naziv nvarchar(30)
)
go
go
create table skolska_godina(
id int primary key identity(1,1),
naziv nvarchar(30)
)
go
go
create table osoba(
id int primary key identity(1,1),
ime nvarchar(30) not null,
prezime nvarchar(30) not null,
adresa nvarchar (80),
jmbg int not null,
email nvarchar(50) not null,
pass nvarchar(30) not null,
uloga nvarchar(50) not null
)
go
go
create table odeljenje(
id int primary key identity(1,1),
razred nvarchar(10) not null,
id_smer int foreign key references smer(id),
id_razredni int foreign key references osoba(id),
id_godina int foreign key references skolska_godina(id)
)
go
go
create table raspodela(
id int primary key identity(1,1),
id_nastavnika int foreign key references osoba(id),
id_godine int foreign key references skolska_godina(id),
id_predmeta int foreign key references predmet(id),
id_odeljenja int foreign key references odeljenje(id)
)
go

go
create table upisnica(
id int primary key identity(1,1),
id_osobe int foreign key references osoba(id),
id_odeljenja int foreign key references odeljenje(id)
)
go
go
create table ocena(
id int primary key identity(1,1),
datum date not null,
ocena int not null,
id_ucenik int foreign key references osoba(id),
id_raspodele int foreign key references raspodela(id)
)
go
select * from osoba

go
alter table odeljenje 
add indeks nvarchar(5) 
go
